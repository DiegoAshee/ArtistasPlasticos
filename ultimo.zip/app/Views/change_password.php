<!DOCTYPE html>
<html>
<head><title>Cambiar contraseña</title></head>
<body>
    <h1>Cambiar contraseña</h1>
    <form method="post">
        <label>Nueva contraseña:</label><br>
        <input type="password" name="new_password" required><br><br>
        <label>Confirmar contraseña:</label><br>
        <input type="password" name="confirm_password" required><br><br>
        <button type="submit">Guardar</button>
    </form>
</body>
</html>
