<?php
// app/Config/config.php
 
// Configuración de la base de datos
define('DB_HOST', 'localhost');
define('DB_NAME', 'algori12_abap');
define('DB_USER', 'algori12_abap');
define('DB_PASS', 'Abap2025*');
 
// Configuraciones generales del sistema
define('BASE_URL', 'https://algoritmos.com.bo/pasantes/jcrojas/');
define('SITE_NAME', 'Sistema MVC');
 
// === DEBUG (para addDebug del controlador) ===
define('APP_DEBUG', true); // ponlo en false en producción
 
// Timezone
date_default_timezone_set('America/La_Paz');
 
// Mostrar errores en desarrollo (mejor no mostrarlos al usuario)
error_reporting(E_ALL & ~E_WARNING & ~E_NOTICE);
ini_set('display_errors', 0);
 
// Logging de errores
$logDir = __DIR__ . '/../../logs';
if (!is_dir($logDir)) {
    mkdir($logDir, 0755, true);
}
ini_set('log_errors', 1);
ini_set('error_log', $logDir . '/php_errors.log');
 
// (Opcional) SMTP...